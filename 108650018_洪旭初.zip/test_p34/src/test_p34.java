import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class test_p34 {

	public static void main(String[] args) throws IOException{
		System.out.println("�п�J�@�Ӿ��");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        

        int num = Integer.parseInt(br.readLine());
        System.out.println("�A��J���O" + num);
	}

}
