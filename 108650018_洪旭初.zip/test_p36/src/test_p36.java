
public class test_p36 {

	public static void main(String[] args) {
		String str = "Hello";  

		char ch1 = str.charAt(0);
		char ch2 = str.charAt(1);
		
        int len = str.length();
        
        System.out.println(str + "���Ĥ@�Ӧr���O" + ch1);
        System.out.println(str + "���ĤG�Ӧr���O" + ch2);
        System.out.println(str + "�����׬O" + len);
	}

}
